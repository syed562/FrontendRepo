export enum Airline{
    INDIGO="INDIGO",
    AIRINDIA="AIRINDIA",
    SPICEJET="SPICEJET"
}