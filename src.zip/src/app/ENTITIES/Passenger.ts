export interface Profile {
  id?:number;
  name: string;
houseNo:string;
  city: string;
  state: string;
    email: string;
  phoneNum: string;
}
