export interface searchReq {
  origin: string;
  destination: string;
   departureDateTime: string; 
}