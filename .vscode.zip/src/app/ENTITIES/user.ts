export interface user{
    username:string;
    password:string;
}