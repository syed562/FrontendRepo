export interface Profile {
  name: string;
  email: string;
  phoneNumber: string;
houseNo:string;
  city: string;
  state: string;
}
